const express = require('express');
const app = express();
const port = 3030;

app.use(express.json());

let id = 1; 
let shopping = [];

function getId() {
    return id++;
}

app.use((req, res, next) => {
    res.once('finish', () => {
      console.log(req.method, req.url, res.statusCode);
    });
    next();
  });

app.get('/shopping', (req, res) => {
    res.json({shopping})  
});

app.get('/shopping/:name', (req, res) => {    
    const name = req.params.name;
    if(!name) {
        res.status(400).end();
        return;
    }

    const items = shopping.find(item => item.name === name);    
        if(items){
            res.json(items);
            return;
        }
    res.status(400).end();
});

app.post('/shopping', (req, res) => {    
    let body = req.body;   
    if(!body.name || typeof body.name !== 'string' || typeof body.amount !== 'number'){
        res.status(404).end(); 
        return;       
    }

    let item = {
        name: body.name,
        amount: body.amount,
    }
    shopping.push(item);        
    res.status(201).json(item)
});

app.put('/shopping/:name', (req, res) => {
    console.log('put', req.params.name);
    let name = req.params.name;
    let item = req.body;

    if(!name || !item.name || typeof item.name !== 'string' || typeof item.amount !== 'number'){
        res.status(400).end();
        return;
    }

    const itemIndex = item.findIndex(item => item.name === name);
    if (itemIndex !== -1) {
      let item = {
        name: body.name,
        amount: body.amount,
      };
      items[itemIndex] = item;
      res.status(200).send(items[itemIndex]);
    } else {
      res.status(404).end();
    }
  });


app.delete('/shopping', (req, res) => {
    shopping = [];
    res.status(204).end();
});


app.listen(port, ()=>{
    console.log('listening on', port);
});