# Uppgift 2

Lägg till eventlyssnare på knapparna i `index.html` filen. När man trycker på en knapp ska du ändra bakgrundsfärgen på `.container` elementet till att vara samma färg som knappen har (röd, grön, blå). Om du vill kan du använda de existerande classerna som är definerade i .css filen.
