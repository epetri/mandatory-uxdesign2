/* Implement your solution here */
 let container = document.querySelector('.container');
 let redButton = document.querySelector('.red');
 let greenButton = document.querySelector('.green');
 let blueButton = document.querySelector('.blue');

 redButton.addEventListener('click', function(){
   container.style.backgroundColor = 'red';
 });

 greenButton.addEventListener('click', function(){
   container.style.backgroundColor = 'green';
 });

 blueButton.addEventListener('click', function(){
   container.style.backgroundColor = 'blue';
 });
 
