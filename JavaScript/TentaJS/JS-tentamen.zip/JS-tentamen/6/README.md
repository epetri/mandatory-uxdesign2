# Uppgift 6

**VG Uppgift**

Du ska skriva en funktion `countCompanies` i `script.js`. Funktionen anropas nu med att skicka ett objekt som representerar en företagskoncern. Du ska räkna hur många företag som finns i koncernen. Du måste lösa uppgiften med en rekursiv funktion.
