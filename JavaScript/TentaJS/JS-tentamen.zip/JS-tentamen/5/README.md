# Uppgift 5

**VG uppgift**    

Skriv JavaScript kod i `script.js`. Ändra ingen HTML eller CSS. Du ska göra så att när vi rör musen så ska den röda bollen följa efter muspekaren. Men bollen måste stanna innanför den gråa boxen. 
