 /*Skriv JavaScript kod i script.js. Ändra ingen HTML eller CSS.
 Du ska göra så att när vi rör musen så ska den röda bollen följa efter muspekaren.
 Men bollen måste stanna innanför den gråa boxen.*/

 let ball = document.querySelector('.ball');
 ball.addEventListener('mouseenter', move());

 let innerbox = document.querySelector('.inner');
 innerbox.onmousemove = function(event){
     let x = event.clientX;
     let y = event.clientY;
     let  coor = {
       xcoords: x,
       ycoords: y
     };
     move(coor);
 }

function move(coordinates){
  let saveX = null;
  let saveY = null;
  for(i in coordinates){
    if(i === 'xcoords'){
      saveX = coordinates[i];
      ball.style.left = saveX + 'px';
    }else if(i === 'ycoords'){
      saveY = coordinates[i];
        ball.style.top = saveY + 'px';
    }
  }
}
