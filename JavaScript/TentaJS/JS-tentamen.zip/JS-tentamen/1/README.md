# Uppgift 1

Skriv en funktion `sum` som tar en array av nummer som argument. Funktionen ska returnera summan av alla tal i arrayen.
