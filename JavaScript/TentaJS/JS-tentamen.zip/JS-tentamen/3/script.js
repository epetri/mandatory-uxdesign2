/* Implement your solution here
Skapa en funktion renderTable som tar en array som argument. Rendera tabellen till DOM:en från funktionen.
Tabellen ska renderas i main elementet. Få exemplet som är skrivet i script.js att fungera.
Din funktion behöver inte hantera generiska kolumner, utan det räcker att exemplet som är angett fungerar.*/

let main = document.querySelector('main');

function renderTable(array){
  let table = document.createElement('table');
  let thead = document.createElement('thead');
  let tbody = document.createElement('tbody');
  let tr = document.createElement('tr');

  main.appendChild(table);
  table.appendChild(thead);
  table.appendChild(tbody);

  let object = array[0];
  for(let key in object) {
    if(key === 'name' || key === 'occupation' || key === 'age'){
      let th = document.createElement('th');
      th.textContent = key;
      tr.appendChild(th);
    }
  }
  thead.appendChild(tr);

  for(let index in array) {
    let tr = document.createElement('tr');
    tbody.appendChild(tr);
    object = array[index];
    for(let key in object){
    if( key === 'name' || key === 'occupation' || key === 'age'){
      let td = document.createElement('td');
      td.textContent = object[key];
      tr.appendChild(td);
   }
  }
 }
}

/* Do not touch anything below this line */
let data = [
  {name: 'Rachel Green', occupation: 'Waitress', age: 24},
  {name: 'Monica Geller', occupation: 'Chef', age: 24},
  {name: 'Phoebe Buffay', occupation: 'Massage therapist', age: 27},
  {name: 'Joey Tribbiani', occupation: 'Actor', age: 25},
  {name: 'Chandler Bing', occupation: 'Transponster?', age: 26},
  {name: 'Ross Geller', occupation: 'Paleontologist', age: 26},
];
renderTable(data);
