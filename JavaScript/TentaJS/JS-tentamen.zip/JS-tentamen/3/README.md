# Uppgift 3

Skapa en funktion `renderTable` som tar en array som argument. Rendera tabellen till DOM:en från funktionen. Tabellen ska renderas i `main` elementet. Få exemplet som är skrivet i `script.js` att fungera. Din funktion behöver inte hantera generiska kolumner, utan det räcker att exemplet som är angett fungerar.
